### API

All APIs uses HTTP POST.

#### How to do HTTP POST

```js
fetch('http://localhost:3000/api/search', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify({
        origin: 'ORD', 
        destination: 'LAX',
        departure_date: "2023-08-04",
        arrive_before: "2023-08-06 12:34:56",
        transfers_less_than: "3",
        transfer_gap: "60",
        allow_cancel: 1,
        allow_delay: 1,
        conditions: [
            {stops_not_contain: "CVG"},
            {stops_must_contain: "SFO"}
        ]
    }),
})
.then(response => response.json())
.then(data => {
    // Do something to update webpage
})
```

#### /api/search

Sample input:

```json
{
    origin: 'ORD', 
    destination: 'LAX',
    departure_date: "2023-08-04",
    arrive_before: "2023-08-06 12:34:56",
    transfers_less_than: "3",
    transfer_gap: "60",
    allow_cancel: 1,
    allow_delay: 1,
    conditions: [
        {stops_not_contain: "CVG"},
        {stops_not_contain: "SEA"},
        {stops_must_contain: "SFO"},
        {stops_must_contain: "LAX"}
    ]
}
```

If a user logs in, then a record will be automatically inserted.

Sample output:

```json
{
    success: true,
    total_time: 249,
    cancel_rate: 0.025993150684931465,
    delay_rate: 0.2484824000000001,
    segments: [
        {
            airline: "DL",
            number: 1717,
            dept_time: "2023-08-04 15:05:00",
            arri_time: "2023-08-04 16:32:00",
            airport_orig: "ORD",
            airport_dest: "MSP",
            airport_name_orig: "Chicago O'Hare International Airport",
            airport_name_dest: "Minneapolis-Saint Paul International Airport",
            city_orig: "Chicago",
            city_dest: "Minneapolis",
            state_orig: "IL",
            state_dest: "MN",
            delay_rate: 0.2678,
            delay_avg: 19.663,
            delay_std: 50.87877408888843,
            cancel_rate: 0,
            delay_rate_per_reason: [
                0.27686703,
                0,
                0.156648451,
                0.1712204,
                0.063752276
            ],
            delay_avg_per_reason: [
                8.39708561,
                0,
                3.85974499,
                7.014571948,
                1.930783242
            ]
            // corresponding to reasons:
            // [air system, security, airline, late aircraft, weather]
        },
        ...
    ]
}
```

If there is no possible iternary:

```json
{
    success: false,
    error: "No itinerary found."
}
```

#### /api/user

Login/register

```json
{
    operation: "login", // or "register"
    email: "root",
    password: "233233"
}
```

The user login state will be set to the user if success.

Logout

```json
{
    operation: "logout",
}
```

Output format will be either

```json
{
    success: true
}
```

or 

```json
{
    success: false,
    error: "some reason"
}
```

#### /api/history

Insert: will be inserted when searching.

List

```json
{
    operation: "list",
}
```

Output

```json
{
    success: true,
    history_list: [
        {
            id: "1"
            comment: "comment",
            insert_time: "2023-12-05T06:05:55.000Z",
            update_time: "2023-12-05T06:05:55.000Z",
            result: {same format as /api/search's output}
      		username: "root"
        },
        ...
    ]
}
```

Delete

```json
{
    operation: "delete",
    history_id: "1"
}
```

Modify comment

```json
{
    operation: "comment",
    history_id: "2",
    comment: "'; select * from User; '"
}
```

