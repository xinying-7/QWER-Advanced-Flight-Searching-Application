# Team002-QWER
This is a project repository for CS411. Our team ID is 002, and the team name is QWER. The URL for this repository is [fa23-cs411-team002-QWER.git].

## Permission
You should make sure you allow TAs to access your repository. You can add TA(s) as a collaborator to your repository.

## Preparing for your release
Eash submission should be in it's own [release](https://docs.github.com/en/repositories/releasing-projects-on-github/about-releases). Release are specific freezes to your repository. You should submit your commit hash on canvas or google sheet. When tagging your stage, please use the tag `stage.x` where x is the number to represent the stage.

## Keeping things up-to-date
You should make sure you keep your project root files up-to-date. Information for each file/folders are explained.

## Code Contribution
Individual code contribution will be used to evaluate individual contribution to the project.
