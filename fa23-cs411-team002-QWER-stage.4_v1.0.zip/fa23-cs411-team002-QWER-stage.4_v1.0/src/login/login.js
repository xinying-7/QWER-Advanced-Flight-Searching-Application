document.addEventListener('DOMContentLoaded', function () {
    // handle register form submission
    const registerForm = document.getElementById('register');
    registerForm.addEventListener('submit', function (event) {
        event.preventDefault();

        const email = registerForm.querySelector('input[type="text"]').value;
        const password = registerForm.querySelector('input[type="password"]').value;

        const data = {
            operation: "register",
            email: email,
            password: password,
        };

        fetch('api/user', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
            .then(response => response.json())
            .then(data => {
                console.log(data);
                if (!data.success && data.error === "Email already exists.") {
                    alert("Email already exists.");
                } else {
                    alert('Registration successful! Please log in.');
                }
            })
            .catch((error) => {
                console.error('Error:', error);
            });
    });


    // handle login form submission
    const loginForm = document.getElementById('login');
    loginForm.addEventListener('submit', function (event) {
        event.preventDefault();

        const email = loginForm.querySelector('input[type="text"]').value;
        const password = loginForm.querySelector('input[type="password"]').value;

        const data = {
            operation: "login",
            email: email,
            password: password
        };

        fetch('api/user', {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Login successful!');
                    window.location.href = '/search';
                } else {
                    alert('Invalid email or password.');
                }
            })
            .catch((error) => {
                console.error('Error:', error);
            });
    });
});