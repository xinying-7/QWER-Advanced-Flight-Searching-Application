// handle Origin and Destination input
const airports = [
    "ABE", "ABI", "ABQ", "ABR", "ABY", "ACK", "ACT", "ACV", "ACY", "ADK", "ADQ", "AEX", "AGS", "AKN", "ALB", "ALO",
    "AMA", "ANC", "APN", "ASE", "ATL", "ATW", "AUS", "AVL", "AVP", "AZO", "BDL", "BET", "BFL", "BGM", "BGR", "BHM",
    "BIL", "BIS", "BJI", "BLI", "BMI", "BNA", "BOI", "BOS", "BPT", "BQK", "BQN", "BRD", "BRO", "BRW", "BTM", "BTR",
    "BTV", "BUF", "BUR", "BWI", "BZN", "CAE", "CAK", "CDC", "CDV", "CEC", "CHA", "CHO", "CHS", "CID", "CIU", "CLD",
    "CLE", "CLL", "CLT", "CMH", "CMI", "CMX", "CNY", "COD", "COS", "COU", "CPR", "CRP", "CRW", "CSG", "CVG", "CWA",
    "DAB", "DAL", "DAY", "DBQ", "DCA", "DEN", "DFW", "DHN", "DIK", "DLG", "DLH", "DRO", "DSM", "DTW", "DVL", "EAU",
    "ECP", "EGE", "EKO", "ELM", "ELP", "ERI", "ESC", "EUG", "EVV", "EWN", "EWR", "EYW", "FAI", "FAR", "FAT", "FAY",
    "FCA", "FLG", "FLL", "FNT", "FSD", "FSM", "FWA", "GCC", "GCK", "GEG", "GFK", "GGG", "GJT", "GNV", "GPT", "GRB",
    "GRI", "GRK", "GRR", "GSO", "GSP", "GST", "GTF", "GTR", "GUC", "GUM", "HDN", "HIB", "HLN", "HNL", "HOB", "HOU",
    "HPN", "HRL", "HSV", "HYA", "HYS", "IAD", "IAG", "IAH", "ICT", "IDA", "ILG", "ILM", "IMT", "IND", "INL", "ISN",
    "ISP", "ITH", "ITO", "JAC", "JAN", "JAX", "JFK", "JLN", "JMS", "JNU", "KOA", "KTN", "LAN", "LAR", "LAS", "LAW",
    "LAX", "LBB", "LBE", "LCH", "LEX", "LFT", "LGA", "LGB", "LIH", "LIT", "LNK", "LRD", "LSE", "LWS", "MAF", "MBS",
    "MCI", "MCO", "MDT", "MDW", "MEI", "MEM", "MFE", "MFR", "MGM", "MHK", "MHT", "MIA", "MKE", "MKG", "MLB", "MLI",
    "MLU", "MMH", "MOB", "MOT", "MQT", "MRY", "MSN", "MSO", "MSP", "MSY", "MTJ", "MVY", "MYR", "OAJ", "OAK", "OGG",
    "OKC", "OMA", "OME", "ONT", "ORD", "ORF", "ORH", "OTH", "OTZ", "PAH", "PBG", "PBI", "PDX", "PHF", "PHL", "PHX",
    "PIA", "PIB", "PIH", "PIT", "PLN", "PNS", "PPG", "PSC", "PSE", "PSG", "PSP", "PUB", "PVD", "PWM", "RAP", "RDD",
    "RDM", "RDU", "RHI", "RIC", "RKS", "RNO", "ROA", "ROC", "ROW", "RST", "RSW", "SAF", "SAN", "SAT", "SAV", "SBA",
    "SBN", "SBP", "SCC", "SCE", "SDF", "SEA", "SFO", "SGF", "SGU", "SHV", "SIT", "SJC", "SJT", "SJU", "SLC", "SMF",
    "SMX", "SNA", "SPI", "SPS", "SRQ", "STC", "STL", "STT", "STX", "SUN", "SUX", "SWF", "SYR", "TLH", "TOL", "TPA",
    "TRI", "TTN", "TUL", "TUS", "TVC", "TWF", "TXK", "TYR", "TYS", "UST", "VEL", "VLD", "VPS", "WRG", "WYS", "XNA",
    "YAK", "YUM"
];

document.addEventListener('DOMContentLoaded', function () {

    // handle reset condition button
    const originalConditionContainer = document.querySelector('.condition-container').innerHTML;
    const resetButton = document.querySelector('.reset');
    if (resetButton) {
        resetButton.addEventListener('click', function (event) {
            event.preventDefault();
            document.querySelector('.condition-container').innerHTML = originalConditionContainer;
        });
    }

    // get history function
    const getHistory = function () {
        fetch('/api/history', {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({operation: "list"})
        })
            .then(response => response.json())
            .then(data => {
                if (!data.success) {
                    alert('Error: ' + data.error);
                    window.location.href = '/';
                }

                const historyContainer = document.querySelector('.history-container ul');
                const loadingSpinner = document.getElementById('loadingSpinner');
                loadingSpinner.style.display = 'block';

                Array.from(historyContainer.children).forEach(child => {
                    if (child.tagName === 'LI') {
                        historyContainer.removeChild(child);
                    }
                });

                // if data.history_list.length === 0, display "No history"
                if (data.history_list.length === 0) {
                    const li = document.createElement('li');
                    li.textContent = 'No history';
                    historyContainer.appendChild(li);
                    historyContainer.style.listStyleType = 'none';
                    loadingSpinner.style.display = 'none';
                }
                else {
                    historyContainer.style.listStyleType = 'none';
                    data.history_list.forEach((item) => {

                        const li = document.createElement('li');

                        const segmentsDiv = document.createElement('div');
                        segmentsDiv.className = 'segments';

                        item.result.segments.forEach((segment, index) => {
                            const segmentDiv = document.createElement('div');
                            segmentDiv.className = 'segment-container';

                            const segmentTitleDiv = document.createElement('div');
                            segmentTitleDiv.className = 'segment-title';
                            segmentTitleDiv.textContent = `Segment ${index + 1}`;

                            const flightDetailsGroupDiv = document.createElement('div');
                            flightDetailsGroupDiv.className = 'flightDetails-group';
                            flightDetailsGroupDiv.innerHTML = `
                        <div class="flightNumber"><p>${segment.airline}${segment.number}</p></div>
                        <div class="departureTime"><p>${segment.dept_time}</p></div>
                        <div class="arrivalTime"><p>${segment.arri_time}</p></div>
                        <div class="departureAirport"><p>${segment.airport_orig} - ${segment.city_orig}</p></div>
                        <div class="arrivalAirport"><p>${segment.airport_dest} - ${segment.city_dest}</p></div>
                    `;

                            const predictGroupDiv = document.createElement('div');
                            predictGroupDiv.className = 'predict-group';
                            predictGroupDiv.innerHTML = `
                            <div class="predictDelay">
                                <p><strong>Expected delay time: </strong>
                                    <u>${Math.round(segment.delay_std)} minutes (${Math.round(segment.delay_rate * 1000) / 10}%)</u>, 
                                    because of: <br/>
                                    air system (${Math.round(segment.delay_rate_per_reason[0] * 1000) / 10}%),
                                    security (${Math.round(segment.delay_rate_per_reason[1] * 1000) / 10}%),
                                    airline (${Math.round(segment.delay_rate_per_reason[2] * 1000) / 10}%),
                                    late aircraft (${Math.round(segment.delay_rate_per_reason[3] * 1000) / 10}%),
                                    weather (${Math.round(segment.delay_rate_per_reason[4] * 1000) / 10}%).
                                </p>
                            </div>
                            <div class="predictCancellation"><p><strong>Cancellation probability:</strong> <u>${Math.round(segment.cancel_rate * 1000) / 10}%</u></p></div>
                    `;

                            segmentDiv.appendChild(segmentTitleDiv);
                            segmentDiv.appendChild(flightDetailsGroupDiv);
                            segmentDiv.appendChild(predictGroupDiv);
                            segmentsDiv.appendChild(segmentDiv);
                            li.appendChild(segmentsDiv);
                        });

                        // handle note modify
                        const note = document.createElement('div');
                        note.className = 'note';
                        note.textContent = ` Note: ${item.comment}`;
                        if (item.comment.length === 0) {
                            note.textContent = ' Note: (Click here to add note)';
                        }
                        note.addEventListener('click', function (event) {
                            event.preventDefault();
                            const noteInput = document.createElement('input');
                            noteInput.type = 'text';
                            noteInput.className = 'note-input';
                            noteInput.placeholder = 'Enter your note here ...';
                            noteInput.value = item.comment;
                            noteInput.addEventListener('keydown', function (event) {
                                if (event.keyCode === 13) { // 13 是回车键的键码
                                    event.preventDefault();
                                    const loadingSpinner = document.getElementById('loadingSpinner');
                                    loadingSpinner.style.display = 'block';
                                    fetch('/api/history', {
                                        method: 'POST',
                                        credentials: 'include',
                                        headers: {
                                            'Content-Type': 'application/json'
                                        },
                                        body: JSON.stringify({
                                            operation: "comment",
                                            history_id: item.id,
                                            comment: noteInput.value
                                        })
                                    })
                                        .then(response => response.json())
                                        .then(data => {
                                            getHistory(); // 重新获取历史记录以更新页面上的注释
                                            loadingSpinner.style.display = 'none';
                                        });
                                    note.textContent = ` Note: ${noteInput.value}`;
                                    noteInput.replaceWith(note);
                                }
                            });
                            note.replaceWith(noteInput);
                            noteInput.focus();
                        });
                        // li.appendChild(note);
                        

                        // handle delete button
                        const deleteButton = document.createElement('button');
                        deleteButton.className = 'remove-history';
                        deleteButton.textContent = 'Delete Record';
                        deleteButton.addEventListener('click', function (event) {
                            event.preventDefault();

                            var result = confirm('Are you sure to delete?');
                            if (result) {
                                const loadingSpinner = document.getElementById('loadingSpinner');
                                loadingSpinner.style.display = 'block';
                                console.log(item.id);
                                fetch('/api/history', {
                                    method: 'POST',
                                    credentials: 'include',
                                    headers: {
                                        'Content-Type': 'application/json'
                                    },
                                    body: JSON.stringify({operation: "delete", history_id: item.id})
                                })
                                    .then(response => response.json())
                                    .then(data => {
                                        getHistory();
                                        loadingSpinner.style.display = 'none';
                                    })
                            }
                            
                        });
                        segmentsDiv.appendChild(note);
                        segmentsDiv.appendChild(deleteButton);
                        li.appendChild(segmentsDiv);
                        historyContainer.appendChild(li);
                    });
                }
                loadingSpinner.style.display = 'none';
            })
    };

    // display history when search page loaded
    getHistory();

    // handle search form submission
    const form_search = document.querySelector('.search-form');
    if (form_search) {
        form_search.addEventListener('submit', function (event) {
            event.preventDefault();

            const inputData = {
                origin: '',
                destination: '',
                departure_date: '',
                arrive_before: '',
                transfers_less_than: '',
                transfer_gap: '',
                allow_cancel: true,
                allow_delay: true,
                conditions: []
            };

            inputData.origin = document.getElementById('origin').value;
            inputData.destination = document.getElementById('destination').value;
            inputData.departure_date = document.getElementById('startDate').value.replace('T', ' ') + ':00';
            inputData.arrive_before = document.getElementById('arrivesBefore').value.replace('T', ' ') + ':00';
            inputData.transfers_less_than = document.querySelector('.transferInput').value;
            inputData.transfer_gap = document.querySelector('.transferGapInput').value;
            inputData.allow_cancel = document.querySelector('.cancellation-select').value;
            inputData.allow_delay = document.querySelector('.delay-select').value;
            document.querySelector('.notContainInput')?.value && inputData.conditions.push({ stops_not_contain: document.querySelector('.notContainInput').value });
            document.querySelector('.containInput')?.value && inputData.conditions.push({ stops_must_contain: document.querySelector('.containInput').value });


            const loadingSpinner = document.getElementById('loadingSpinner');
            loadingSpinner.style.display = 'block';

            fetch('/api/search', {
                method: 'POST',
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(inputData)
            })
                .then(response => response.json())
                .then(data => {

                    const resultContainer = document.querySelector('.result-container');

                    console.log(data);

                    if (data.success) {
                        resultContainer.innerHTML = `
                            <header><div class="title">Best Choice of Flight</div>
                            <p><strong>Total travelling time:</strong> <u>` + data["total_time"] + ` minutes</u>.</p></header>
                        `;

                        const segmentsDiv = document.createElement('div');
                        segmentsDiv.className = 'segments';

                        data.segments.forEach((segment, index) => {
                            const segmentDiv = document.createElement('div');
                            segmentDiv.classList.add('segment-container');
                            segmentDiv.innerHTML = `
                                <div class="segment-title">Segment ${index + 1}</div>
                                <div class="flightDetails-group">
                                    <div class="flightNumber"><p>${segment.airline}${segment.number}</p></div>
                                    <div class="departureTime"><p>${segment.dept_time}</p></div>
                                    <div class="arrivalTime"><p>${segment.arri_time}</p></div>
                                    <div class="departureAirport"><p>${segment.airport_orig} - ${segment.city_orig}</p></div>
                                    <div class="arrivalAirport"><p>${segment.airport_dest} - ${segment.city_dest}</p></div>
                                </div>
                                <div class="predict-group">
                                    <div class="predictDelay">
                                        <p><strong>Expected delay time: </strong>
                                            <u>${Math.round(segment.delay_std)} minutes (${Math.round(segment.delay_rate * 1000) / 10}%)</u>, 
                                            because of: <br/>
                                            air system (${Math.round(segment.delay_rate_per_reason[0] * 1000) / 10}%),
                                            security (${Math.round(segment.delay_rate_per_reason[1] * 1000) / 10}%),
                                            airline (${Math.round(segment.delay_rate_per_reason[2] * 1000) / 10}%),
                                            late aircraft (${Math.round(segment.delay_rate_per_reason[3] * 1000) / 10}%),
                                            weather (${Math.round(segment.delay_rate_per_reason[4] * 1000) / 10}%).
                                        </p>
                                    </div>
                                    <div class="predictCancellation"><p><strong>Cancellation probability:</strong> <u>${Math.round(segment.cancel_rate * 1000) / 10}%</u></p></div>
                                </div>
                            `;
                            segmentsDiv.appendChild(segmentDiv);
                            resultContainer.appendChild(segmentsDiv);
                            getHistory();
                        });
                    } else {
                        resultContainer.innerHTML = `
                        <header>
                            <div class="title">Best Choice of Flight</div>
                            <p>Unable to find such a flight.</p>
                        </header>
                        `;

                    }

                    loadingSpinner.style.display = 'none';
                })
                .catch((error) => {
                    console.error('Error:', error);
                });
        });
    }
});