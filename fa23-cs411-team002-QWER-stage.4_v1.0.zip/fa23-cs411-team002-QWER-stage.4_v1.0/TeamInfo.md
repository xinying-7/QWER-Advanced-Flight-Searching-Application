# team002-QWER

## Basic Information

|   Info      |       Description      |
| ----------- | ---------------------- |
| TeamID      |        Team-002        |
| TeamName    |          QWER          |
| Captain     |       Junkun Chen      |
| Captain     |  junkun3@illinois.edu  |
| Member1     |       Weixian Yi       |
| Member1     |  weixian3@illinois.edu |
| Member2     |       Xinying Lyu      |
| Member2     |  xinying7@illinois.edu |
| Member3     |        Yuan Xu         |
| Member3     |  yuanxu4@illinois.edu  |

## Project Information

|   Info      |            Description           |
| ----------- | -------------------------------- |
|  Title      |  Enhancing Air Travel Efficiency |
| System URL  |           link_to_system         |
| Video Link  |           link_to_video          |

## Project Summary

This project aims to analyze and extract valuable insights from the dataset of flight delays and cancellations in the year 2015, provided by the U.S. Department of Transportation's (DOT) Bureau of Transportation Statistics. 

The outcomes of this project will provide assistance to airlines and airports, enhancing their operational efficiency. Moreover, it will be a valuable resource for travelers seeking to make informed decisions regarding their air travel plans. To achieve these objectives, our project will involve data cleaning, exploratory data analysis (EDA), and database modeling techniques. Additionally, we will utilize data visualization methods to effectively communicate their interested options to the audience.