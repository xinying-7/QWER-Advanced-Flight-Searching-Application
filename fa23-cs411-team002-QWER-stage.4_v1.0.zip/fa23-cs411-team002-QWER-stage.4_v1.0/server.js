process.env.TZ = 'America/Chicago';

const express = require('express');
const session = require('express-session');
const path = require('path');
const mysql = require('mysql');
const { all } = require('express/lib/application');
const app = express();
const crypto = require('crypto');
const { json } = require('express/lib/response');

app.use(express.json());
app.use(express.static(path.join(__dirname, 'src')));
app.use(session({
    secret: 'fa23-cs411-team002-QWER-1ce37eadb85f8469ae267ce7f068ca56',
    resave: false,
    saveUninitialized: true
}));

// index login page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, './src/login', 'login.html'));
});

// search page
app.get('/search', (req, res) => {
    res.sendFile(path.join(__dirname, './src/search', 'search.html'));
});

function sql_query_prefix(num_segments, airport_orig, airport_dest) {
    prefix = ""
}

app.post('/api/search', (req, res) => {
    const db = mysql.createConnection({
        host: '34.28.35.203',
        user: 'root',
        password: '',
        database: 'flights_db',
    });

    db.connect(err => {
        if (err) throw err;
    });


    const args = req.body;
    const RECORD_YEAR = 2015;
    airport_orig = args['origin'];
    airport_dest = args['destination'];
    departure = args['departure_date'];
    arrive_before = args['arrive_before'];
    transfer_gap = parseInt(args['transfer_gap']);
    max_seg = parseInt(args['transfers_less_than']);

    no_cancel = args['allow_cancel'] == "false";
    no_delay = args['allow_delay'] == "false";
    extra_condition_list = args['conditions'];

    username = req.session.user;
    if (username == undefined) {
        console.log("User not logged in.");
    } else {
        console.log("User " + username + " logged in.");
    }
    console.log("airport_orig = " + airport_orig);
    console.log("airport_dest = " + airport_dest);
    console.log("departure = " + departure);
    console.log("arrive_before = " + arrive_before);
    console.log("transfer_gap = " + transfer_gap);
    console.log("max_seg = " + max_seg);
    console.log("no_cancel = " + no_cancel + " | " + args['allow_cancel']);
    console.log("no_delay = " + no_delay + " | " + args['allow_delay']);
    console.log("extra_condition_list = " + extra_condition_list);


    db.query('DROP TEMPORARY TABLE IF EXISTS RelatedRecords;', (err, results) => {
        if (err) throw err;
    });

    query = `CREATE TEMPORARY TABLE RelatedRecords AS`;

    cross_year = false;
    dept_year = parseInt(departure.substring(0, 4));
    arri_year = parseInt(arrive_before.substring(0, 4));
    mov_year = dept_year - RECORD_YEAR;

    if (dept_year == arri_year) {
        query += `
            select * from (
                select 
                    id as record_id,
                    airline, 
                    number,
                    CONCAT(DATE_ADD(date, INTERVAL ` + mov_year + ` YEAR), ' ', scheduled_departure_time) as dept_time,
                    if (
                        scheduled_arrival_time >= scheduled_departure_time,
                        CONCAT(DATE_ADD(date, INTERVAL ` + mov_year + ` YEAR), ' ', scheduled_arrival_time),
                        CONCAT(DATE_ADD(DATE_ADD(date, INTERVAL 1 DAY), INTERVAL ` + mov_year + ` YEAR), ' ', scheduled_arrival_time)
                    ) as arri_time,
                    schedualed_time as scheduled_time
                from Flight_Record
                where '` + RECORD_YEAR + departure.substring(4, 10) + `' <= date AND date <= '` + RECORD_YEAR + arrive_before.substring(4, 10) + `'
            ) tmp_record_only natural join Flight
            where 1=1`;
    } else {
        if (dept_year + 1 != arri_year) {
            res.send({Error: "Departure and arrival dates are too far apart."});
            db.end();
            return;
        }

        cross_year = true;
        query += `
            select * from ((
                select 
                    id as record_id,
                    airline, 
                    number,
                    CONCAT(DATE_ADD(date, INTERVAL ` + mov_year + ` YEAR), ' ', scheduled_departure_time) as dept_time,
                    if (
                        scheduled_arrival_time >= scheduled_departure_time,
                        CONCAT(DATE_ADD(date, INTERVAL ` + mov_year + ` YEAR), ' ', scheduled_arrival_time),
                        CONCAT(DATE_ADD(DATE_ADD(date, INTERVAL 1 DAY), INTERVAL ` + mov_year + ` YEAR), ' ', scheduled_arrival_time)
                    ) as arri_time,
                    schedualed_time as scheduled_time
                from Flight_Record
                where '` + RECORD_YEAR + departure.substring(4, 10) + `' <= date
            ) union (
                select 
                    id as record_id,
                    airline, 
                    number,
                    CONCAT(DATE_ADD(date, INTERVAL ` + (mov_year + 1) + ` YEAR), ' ', scheduled_departure_time) as dept_time,
                    if (
                        scheduled_arrival_time >= scheduled_departure_time,
                        CONCAT(DATE_ADD(date, INTERVAL ` + (mov_year + 1) + ` YEAR), ' ', scheduled_arrival_time),
                        CONCAT(DATE_ADD(DATE_ADD(date, INTERVAL 1 DAY), INTERVAL ` + (mov_year + 1) + ` YEAR), ' ', scheduled_arrival_time)
                    ) as arri_time,
                    schedualed_time as scheduled_time
                from Flight_Record
                where date <= '` + RECORD_YEAR + arrive_before.substring(4, 10) + `'
            )) tmp_record_only natural join Flight
            where 1=1`;
    }
    if (no_cancel) {
        query += ` AND stat_cancel_rate <= 0.0001`;
    }
    if (no_delay) {
        query += ` AND stat_delay_rate <= 0.1`;
    }
    query += ';';
    console.log(query);
    db.query(query, (err, results) => {
        if (err) throw err;
        console.log("[MySQL] Create RelatedRecords Table");
        console.log(results);
    });

    // db.query("select * from RelatedRecords order by dept_time limit 1", (err, results) => {
    //     if (err) throw err;
    //     console.log(results);
    // });
    // db.query("select * from RelatedRecords order by dept_time desc limit 1", (err, results) => {
    //     if (err) throw err;
    //     console.log(results);
    // });

    cur_path_table = `SegPath1`;
    db.query('DROP TEMPORARY TABLE IF EXISTS ' + cur_path_table + ';', (err, results) => {
        if (err) throw err;
    });
    query = `CREATE TEMPORARY TABLE ` + cur_path_table + ` AS
        select 
            R.scheduled_time as total_time,
            R.stat_cancel_rate as cancel_rate,
            R.stat_delay_rate as delay_rate,
            R.record_id as seg1_record_id, 
            R.airline as seg1_airline, 
            R.number as seg1_number, 
            R.dept_time as seg1_dept_time, 
            R.arri_time as seg1_arri_time,
            R.destination_airport as seg1_dest
        from RelatedRecords R
        where R.origin_airport = '` + airport_orig + `' AND '` + departure +  `' <= R.dept_time
        order by R.scheduled_time asc
        LIMIT 200000;`;

    fields = `seg1_record_id, seg1_airline, seg1_number, seg1_dept_time, seg1_arri_time, seg1_dest`;
    console.log("Build " + cur_path_table);
    console.log(query);
    db.query(query, (err, results) => {
        if (err) throw err;
        console.log(results);
    });

    candidate_itineraries = []
    completed_queries = 0;
    current_known_min_time = 9999999999;

    for (num_seg = 1; num_seg <= max_seg; ++num_seg) {
        console.log("num_seg = " + num_seg);

        // Find the path ends on airport_dest in cur_path_table
        query = `
            select *
            from ` + cur_path_table + `
            where seg` + num_seg + `_dest = '` + airport_dest + `' AND seg` + num_seg + `_arri_time <= '` + arrive_before + `'`;

        for (const the_condition of extra_condition_list) {
            for (const [cond, values] of Object.entries(the_condition)) {
                for (value of values.split(/[\s,]+/)) {
                    if (value.length == 0) continue;

                    if (cond == "stops_not_contain") {
                        query += `
                            AND (1=1`;

                        for (i = 1; i < num_seg; ++i) {
                            query += `
                                AND seg` + i + `_dest <> '` + value + `'`;
                        }

                        query += `
                            )`;
                    }
                    if (cond == "stops_must_contain" && value != airport_orig && value != airport_dest) {
                        query += `
                            AND (0=1`;

                        for (i = 1; i < num_seg; ++i) {
                            cur_seg = `seg` + i;
                            query += `
                                OR seg` + i + `_dest = '` + value + `'`;
                        }

                        query += `
                            )`;
                    }
                }
            }
        }
        query += `
            order by total_time asc
            limit 1;
        `

        console.log(query);
        db.query(query, (err, results) => {
            if (err) throw err;
            results.forEach(row => {
                candidate_itineraries.push(JSON.stringify(row));
                // console.log("Found Itinerary: " + JSON.stringify(row));
                if (current_known_min_time > row['total_time']) {
                    current_known_min_time = row['total_time'];
                    console.log("Update current_known_min_time = " + current_known_min_time);
                }
            });
            completed_queries += 1;
        });

        // Extend the path to num_seg + 1
        if (num_seg == max_seg) { continue; }
        prev_path_table = cur_path_table;
        cur_path_table = `SegPath` + (num_seg + 1);
        db.query('DROP TEMPORARY TABLE IF EXISTS ' + cur_path_table + ';', (err, results) => {
            if (err) throw err;
        });
        function max(a, b) {
            if (a > b) return a;
            return b;
        }
        query = `CREATE TEMPORARY TABLE ` + cur_path_table + ` AS
            select
                (P.total_time + TIMESTAMPDIFF(MINUTE, P.seg` + num_seg + `_arri_time, R.dept_time) + R.scheduled_time) as total_time,
                1 - ((1 - P.cancel_rate) * (1 - R.stat_cancel_rate)) as cancel_rate,
                1 - ((1 - P.delay_rate) * (1 - R.stat_delay_rate)) as delay_rate,
                ` + fields + `, 
                R.record_id as seg` + (num_seg + 1) + `_record_id,
                R.airline as seg` + (num_seg + 1) + `_airline,
                R.number as seg` + (num_seg + 1) + `_number,
                R.dept_time as seg` + (num_seg + 1) + `_dept_time,
                R.arri_time as seg` + (num_seg + 1) + `_arri_time,
                R.destination_airport as seg` + (num_seg + 1) + `_dest
            from 
                (
                    select * from ` + prev_path_table + `
                    order by total_time
                    limit ` + max(3000 - num_seg * 750, 500) + `
                ) P join RelatedRecords R on
                (
                    (P.seg` + num_seg + `_dest = R.origin_airport) AND
                    (DATE_ADD(P.seg` + num_seg + `_arri_time, INTERVAL ` + transfer_gap + ` MINUTE) <= R.dept_time)
                )
            order by (P.total_time + TIMESTAMPDIFF(MINUTE, P.seg` + num_seg + `_arri_time, R.dept_time) + R.scheduled_time) asc
            LIMIT 200000;
        `;
        fields += `,
            seg` + (num_seg + 1) + `_record_id, seg` + (num_seg + 1) + `_airline, seg` + (num_seg + 1) + `_number, seg` + (num_seg + 1) + `_dept_time, seg` + (num_seg + 1) + `_arri_time, seg` + (num_seg + 1) + `_dest`;
        console.log("Build " + cur_path_table);
        console.log(query);
        db.query(query, (err, results) => {
            if (err) throw err;
            console.log(results);
        });

    }

    let intervalId = setInterval(() => {
        if (completed_queries == max_seg) {
            clearInterval(intervalId);

            console.log("candidate_itineraries: ");
            min_total_time = 9999999999;
            best_iternary = {success: false, error: "No itinerary found."};
            for (const itinerary of candidate_itineraries) {
                console.log(itinerary);
                if (min_total_time > JSON.parse(itinerary)['total_time']) {
                    min_total_time = JSON.parse(itinerary)['total_time'];
                    best_iternary = JSON.parse(itinerary);
                }
            }
            if (best_iternary['success'] == false) {
                res.send(best_iternary);
                db.end();
                clearInterval(intervalId);
                return;
            }

            ret = {
                success: true,
                raw_itinerary: best_iternary,
                total_time: best_iternary['total_time'],
                cancel_rate: best_iternary['cancel_rate'],
                delay_rate: best_iternary['delay_rate'],
                segments: []
            };
            query = "insert into QueryFlight(airline, number) values "
            for (i = 1; i <= max_seg; ++i) {
                if (best_iternary['seg' + i + '_record_id'] == undefined) break;
                airline = best_iternary['seg' + i + '_airline'];
                number = best_iternary['seg' + i + '_number'];
                ret['segments'].push({
                    airline: airline,
                    number: number,
                    dept_time: best_iternary['seg' + i + '_dept_time'],
                    arri_time: best_iternary['seg' + i + '_arri_time']
                });
                query += "('" + airline + "', '" + number + "'),";
            }
            query = query.substring(0, query.length - 1) + ";";
            console.log(query);

            completed = false;
            db.query(`DROP TEMPORARY TABLE IF EXISTS QueryFlight;`, (err, results) => {
                if (err) throw err;
                db.query(`
                    CREATE TEMPORARY TABLE QueryFlight (
                        airline CHAR(2),
                        number INT,
                        
                        airport_orig CHAR(3),
                        airport_dest CHAR(3),
                        airport_name_orig CHAR(255),
                        airport_name_dest CHAR(255),
                        city_orig char(32),
                        city_dest char(32),
                        state_orig char(32),
                        state_dest char(32),
                        
                        delay_rate DOUBLE,
                        delay_avg DOUBLE,
                        delay_std DOUBLE,
                        cancel_rate DOUBLE,
                        
                        delay_rate_1 DOUBLE,
                        delay_avg_1 DOUBLE,
                        delay_rate_2 DOUBLE,
                        delay_avg_2 DOUBLE,
                        delay_rate_3 DOUBLE,
                        delay_avg_3 DOUBLE,
                        delay_rate_4 DOUBLE,
                        delay_avg_4 DOUBLE,
                        delay_rate_5 DOUBLE,
                        delay_avg_5 DOUBLE
                    );
                `, (err, results) => {
                    if (err) throw err;
                    db.query(query, (err, results) => {
                        if (err) throw err;
                        db.query("CALL FillQueryFlightData();", (err, results) => {
                            if (err) throw err;
                            db.query("select * from QueryFlight;", (err, results) => {
                                if (err) throw err;
                                k = 0;
                                for (row of results) {
                                    ret['segments'][k]['airport_orig'] = row['airport_orig'];
                                    ret['segments'][k]['airport_dest'] = row['airport_dest'];
                                    ret['segments'][k]['airport_name_orig'] = row['airport_name_orig'];
                                    ret['segments'][k]['airport_name_dest'] = row['airport_name_dest'];
                                    ret['segments'][k]['city_orig'] = row['city_orig'];
                                    ret['segments'][k]['city_dest'] = row['city_dest'];
                                    ret['segments'][k]['state_orig'] = row['state_orig'];
                                    ret['segments'][k]['state_dest'] = row['state_dest'];
                                    ret['segments'][k]['delay_rate'] = row['delay_rate'];
                                    ret['segments'][k]['delay_avg'] = row['delay_avg'];
                                    ret['segments'][k]['delay_std'] = row['delay_std'];
                                    ret['segments'][k]['cancel_rate'] = row['cancel_rate'];
                                    ret['segments'][k]['delay_rate_per_reason'] = [row['delay_rate_1'], row['delay_rate_2'], row['delay_rate_3'], row['delay_rate_4'], row['delay_rate_5']];
                                    ret['segments'][k]['delay_avg_per_reason'] = [row['delay_avg_1'], row['delay_avg_2'], row['delay_avg_3'], row['delay_avg_4'], row['delay_avg_5']];

                                    k += 1;
                                }
                                completed = true;
                            });
                        });
                    });
                });
            });
            
            let inner_intv = setInterval(() => {
                if (completed) {
                    if (username != undefined) {
                        db.query(`
                            insert into User_History(username, result, comment) 
                            values (?, ?, '');
                        `, [username, JSON.stringify(ret)], (err, results) => {
                            if (err) throw err;
                            console.log(results);
                            console.log("successfully inserted into User_History");

                            db.end();
                            res.send(ret);
                            clearInterval(intervalId);
                        });
                    } else {
                        db.end();
                        res.send(ret);
                        clearInterval(intervalId);
                    }
                    clearInterval(inner_intv);
                }
            }, 100);
        }
    }, 500);


});

app.post('/api/user', (req, res) => {
    const db = mysql.createConnection({
        host: '34.28.35.203',
        user: 'root',
        password: '',
        database: 'flights_db',
    });

    db.connect(err => {
        if (err) throw err;
    });


    const args = req.body;
    email = args['email'];
    password = args['password'];
    operation = args['operation'];

    function md5(string) {
        return crypto.createHash('md5').update(string).digest('hex');
    }
    password = md5(password);

    console.log("email = " + email);
    console.log("password = " + password);
    console.log("operation = " + operation);

    if (operation == "login") {
        query = `
            select * from User
            where email = '` + email + `' AND password = '` + password + `'
        `;
        console.log(query);
        db.query(query, (err, results) => {
            if (err) throw err;
            console.log(results);
            if (results.length == 0) {
                res.send({
                    success: false,
                    error: "Invalid email or password."
                });
                db.end();
            } else {
                req.session.user = email;
                res.send({
                    success: true,
                    email: email
                });
                db.end();
            }
        });
    } else if (operation == "register") {
        query = `
            select * from User
            where email = '` + email + `'
        `;
        console.log(query);
        db.query(query, (err, results) => {
            if (err) throw err;
            console.log(results);
            if (results.length > 0) {
                res.send({
                    success: false,
                    error: "Email already exists."
                });
                db.end();
            } else {
                query = `
                    insert into User (email, password)
                    values ('` + email + `', '` + password + `')
                `;
                console.log(query);
                db.query(query, (err, results) => {
                    if (err) throw err;
                    console.log(results);
                    req.session.user = email;
                    res.send({
                        success: true,
                        email: email
                    });
                    db.end();
                });
            }
        });
    } else if (operation == "logout") {
        req.session.destroy();
        res.send({
            success: true
        });
        db.end();
    } else {
        res.send({
            success: false,
            error: "Invalid operation."
        });
        db.end();
    }

});

app.post('/api/history', (req, res) => {
    const db = mysql.createConnection({
        host: '34.28.35.203',
        user: 'root',
        password: '',
        database: 'flights_db',
    });

    db.connect(err => {
        if (err) throw err;
    });


    const args = req.body;
    operation = args['operation'];
    history_id = args['history_id'];
    comment = args['comment'];
    username = req.session.user;
    if (username == undefined) {
        res.send({
            success: false,
            error: "User not logged in."
        });
        db.end();
        return;
    }

    if (operation == "list") {
        query = `
            select * from User_History
            where username = '` + username + `'
            order by id desc
        `;
        console.log(query);
        db.query(query, (err, results) => {
            if (err) throw err;
            // console.log(results);
            ret = JSON.parse(JSON.stringify(results));
            for (i = 0; i < ret.length; ++i) {
                ret[i]['result'] = JSON.parse(ret[i]['result']);
            }
            res.send({
                success: true,
                history_list: ret
            });
        });
    } else if (operation == "comment") {
        db.query(`
            update User_History
            set comment = ?
            where id = ? AND username = ?
        `, [comment, history_id, username], (err, results) => {
            if (err) throw err;
            console.log(results);
            if (results.affectedRows == 0) {
                res.send({
                    success: false,
                    error: "Invalid history or unmatched username."
                });
            } else {
                res.send({
                    success: true
                });
            }
        });
    } else if (operation == "delete") {
        db.query(`
            delete from User_History
            where id = ? AND username = ?
        `, [history_id, username], (err, results) => {
            if (err) throw err;
            console.log(results);
            if (results.affectedRows == 0) {
                res.send({
                    success: false,
                    error: "Invalid history or unmatched username."
                });
            } else {
                res.send({
                    success: true
                });
            }
        });
    } else res.send({
        success: false,
        error: "Invalid operation."
    });

    db.end();

});

// Set the port and start the server
const PORT = process.env.PORT || 80;
app.listen(PORT, () => {
    console.log(`======== Server running on port ${PORT} ========`);
});
